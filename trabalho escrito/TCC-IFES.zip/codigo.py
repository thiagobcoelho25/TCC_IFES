import random
class Individuo():
  def __init__(self, lista_distritos_existentes: list, df: geopandas.GeoDataFrame, soma_populacao: int,geracao=0):
    self.geracao = geracao
    self.lista_distritos_existentes = lista_distritos_existentes
    self.nota_avaliacao = 0
    self.cromossomo = []
    self.df = df
    self.soma_populacao = soma_populacao
    
  def gerar_primeira_geracao(self, tamanho_cromossomo: int, dicionario_adjacencia: dict):
    self.cromossomo = ['' for x in range(tamanho_cromossomo)]

    bairros_selecionados = random.sample(range(0, 69), len(self.lista_distritos_existentes))
    for idx, distrito in enumerate(self.lista_distritos_existentes):
      self.cromossomo[bairros_selecionados[idx]] = distrito

    preenchimento_completo = False
    while preenchimento_completo != True:
      preenchimento_completo = True
      for idx, bairro  in enumerate(self.cromossomo):
        if bairro != '':
          #print("Bairro: ",bairro)
          bairros_adjacentes = dicionario_adjacencia[idx]
          #print("Bairros adjacentes: ", bairros_adjacentes)
          for bairro_adjacente in bairros_adjacentes:
            if self.cromossomo[bairro_adjacente] == '':
              self.cromossomo[bairro_adjacente] = bairro
        else:
          preenchimento_completo = False
  
  def soma_populacao_distrito(self, bairros_distrito: geopandas.GeoDataFrame):
    soma_populacao_distrito = bairros_distrito['população'].sum()
    soma_populacao_distrito = soma_populacao_distrito - round(self.soma_populacao/len(self.lista_distritos_existentes))
    return abs(soma_populacao_distrito)
  
  def soma_distancia_entre_centroids(self, bairros_distrito: geopandas.GeoDataFrame):
    centroides_dos_bairro = bairros_distrito.centroid
    centroide_principal = bairros_distrito.dissolve().centroid
    soma_distancia_entre_centroids = centroides_dos_bairro.distance(centroide_principal[0]).sum()
    return soma_distancia_entre_centroids
  
  def funcao_fitness(self):
    soma_total_populacao = 0
    soma_total_distancia = 0
    for i, distrito in enumerate(self.lista_distritos_existentes):
      bairros_pertencentes_distrito = [idx for idx, element in enumerate(self.cromossomo) if element == distrito]
      dataframe_bairros_pertencentes_distrito = self.df[self.df['id'].isin(bairros_pertencentes_distrito)] # ou dataset_cachoeiro.iloc[[53,16,20,49,47]]
      if self.verifica_contiguidade(dataframe_bairros_pertencentes_distrito) > 1:
        self.nota_avaliacao = 999999999
        return
      
      soma_total_populacao += self.soma_populacao_distrito(dataframe_bairros_pertencentes_distrito)
      soma_total_distancia += self.soma_distancia_entre_centroids(dataframe_bairros_pertencentes_distrito)
    self.nota_avaliacao = soma_total_populacao + soma_total_distancia
  
  def verifica_contiguidade(self, bairros_distrito: geopandas.GeoDataFrame):
    if len(bairros_distrito) < 1:
      return 2
    w = libpysal.weights.Queen.from_dataframe(bairros_distrito,silence_warnings=True)
    return w.n_components # Peguei da documentação https://pysal.org/libpysal/generated/libpysal.weights.W.html
  
  def crossover(self, outro_individuo):
    ponto_corte = round(random.random() * len(self.cromossomo))

    cromossomo_filho_1 = outro_individuo.cromossomo[0:ponto_corte] + self.cromossomo[ponto_corte::]
    cromossomo_filho_2 = self.cromossomo[0:ponto_corte] + outro_individuo.cromossomo[ponto_corte::]

    filhos = [Individuo(self.lista_distritos_existentes, self.df, self.soma_populacao ,self.geracao + 1),
              Individuo(self.lista_distritos_existentes, self.df, self.soma_populacao, self.geracao + 1)]
    
    filhos[0].cromossomo = cromossomo_filho_1
    filhos[1].cromossomo = cromossomo_filho_2

    return filhos
  
  def mutacao(self, taxa_mutacao):
    for i in range(len(self.cromossomo)):
      if random.random() < taxa_mutacao:
        distrito_escolhido = round(random.random() * (len(self.lista_distritos_existentes) - 1))
        self.cromossomo[i] = self.lista_distritos_existentes[distrito_escolhido]
    return self
